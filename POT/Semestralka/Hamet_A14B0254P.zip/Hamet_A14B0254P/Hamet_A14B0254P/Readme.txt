-------- PROJECT GENERATOR --------
PROJECT NAME :	Hamet_A14B0254P
PROJECT DIRECTORY :	C:\School\POT\Workspace\Hamet_A14B0254P\Hamet_A14B0254P
CPU SERIES :	2600
CPU TYPE :	Other
TOOLCHAIN NAME :	KPIT GNUH8 [ELF] Toolchain
TOOLCHAIN VERSION :	v11.02
GENERATION FILES :
    C:\School\POT\Workspace\Hamet_A14B0254P\Hamet_A14B0254P\start.asm
        Reset Program
    C:\School\POT\Workspace\Hamet_A14B0254P\Hamet_A14B0254P\inthandler.c
        Interrupt Handler
    C:\School\POT\Workspace\Hamet_A14B0254P\Hamet_A14B0254P\vects.c
        Vector Table
    C:\School\POT\Workspace\Hamet_A14B0254P\Hamet_A14B0254P\iodefine.h
        Definition of I/O Register
    C:\School\POT\Workspace\Hamet_A14B0254P\Hamet_A14B0254P\inthandler.h
        Interrupt Handler Declarations
    C:\School\POT\Workspace\Hamet_A14B0254P\Hamet_A14B0254P\hwinit.c
        Hardware Setup file
    C:\School\POT\Workspace\Hamet_A14B0254P\Hamet_A14B0254P\typedefine.h
        Aliases of Integer Type
    C:\School\POT\Workspace\Hamet_A14B0254P\Hamet_A14B0254P\intrinsic.h
        Intrinsic header file
    C:\School\POT\Workspace\Hamet_A14B0254P\Hamet_A14B0254P\Hamet_A14B0254P.c
        Main Program
START ADDRESS OF SECTION :
    0x000000800	.text,.rodata
    0x000FFEC00	.data,.bss
    0x00FFC000	.stack

SELECT TARGET :
    H8S/2600A Simulator
DATE & TIME : 5/9/2015 8:23:22 PM

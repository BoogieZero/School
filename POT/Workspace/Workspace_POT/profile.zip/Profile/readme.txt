-------- PROJECT GENERATOR --------
PROJECT NAME :	Project_2
PROJECT DIRECTORY :	D:\MCU\H8S\Asembler H8S\Workspace ELF\Project_2
CPU SERIES :	2600
CPU TYPE :	Other
TOOLCHAIN NAME :	KPIT GNUH8 [ELF] Toolchain
TOOLCHAIN VERSION :	v0801
GENERATION FILES :
    D:\MCU\H8S\Asembler H8S\Workspace ELF\Project_2\start.asm
        Reset Program
    D:\MCU\H8S\Asembler H8S\Workspace ELF\Project_2\inthandler.c
        Interrupt Handler
    D:\MCU\H8S\Asembler H8S\Workspace ELF\Project_2\vects.c
        Vector Table
    D:\MCU\H8S\Asembler H8S\Workspace ELF\Project_2\iodefine.h
        Definition of I/O Register
    D:\MCU\H8S\Asembler H8S\Workspace ELF\Project_2\inthandler.h
        Interrupt Handler Declarations
    D:\MCU\H8S\Asembler H8S\Workspace ELF\Project_2\hwinit.c
        Hardware Setup file
    D:\MCU\H8S\Asembler H8S\Workspace ELF\Project_2\typedefine.h
        Aliases of Integer Type
    D:\MCU\H8S\Asembler H8S\Workspace ELF\Project_2\Project_2.c
        Main Program
START ADDRESS OF SECTION :
    0x000000800	.text,.rodata
    0x000FFEC00	.data,.bss
    0x00FFC000	.stack

SELECT TARGET :
    H8S/2600A Simulator
DATE & TIME : 7.2.2008 13:04:16

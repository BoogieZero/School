================================================================================
NÁZEV PROJEKTU:  DCV 04 příprava a využití Přepravky, výčtový typ
================================================================================

AUTOR:           Pavel Herout 
VERZE A DATUM:   3.0 - 24.8.2012
================================================================================


ÚČEL PROJEKTU:
==============
Projekt slouží k procvičení práce s konstruktory, přepravkami a 
výčtovým typem


INSTRUKCE PRO UŽIVATELE:
========================
Jsou uvedeny v zadání.

JAK PROJEKT SPUSTIT:
====================
Po celkovém odladění stiskněte tlačítko Spustit testy

================================================================================

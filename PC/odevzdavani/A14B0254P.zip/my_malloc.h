#ifndef _MY_MALLOC_H
#define _MY_MALLOC_H
#include <stdlib.h>

/*
Overrided malloc.
*/
void *my_malloc(size_t size);

#endif
